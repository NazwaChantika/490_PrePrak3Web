import React from 'react';
import Hero from 'D:/Semester 5/Web/latihanprak3w/my-react-app/src/components/Hero.jsx';

function Home() {
return (
    <div>
        <Hero />
    </div>
);
}

export default Home;